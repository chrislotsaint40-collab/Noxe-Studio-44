# NEXO ESTÚDIO — Android app (v1.1)

A native Android starter project for the NEXO ESTÚDIO digital-products storefront concept. UI language: English and Portuguese. Intended launch-market configuration: United States and other supported countries, excluding Brazil.

## Build the APK with GitHub Actions

1. Download and extract this ZIP on your computer.
2. Create a GitHub repository.
3. Upload the **contents** of this folder to the repository root (the `.github` folder must also be uploaded).
4. Open the repository's **Actions** tab.
5. Select **Build NEXO STUDIO Android APK** and choose **Run workflow**.
6. Open the completed run and download the `NEXO-STUDIO-APK` artifact. The file inside is `app-debug.apk`.

The workflow also runs on pushes to `main` or `master`.

## App features included

- NEXO ESTÚDIO visual identity and supplied logo image in the home screen.
- Native Android launcher icon.
- English/Portuguese language toggle.
- Home, Store, NEXO AI and Profile sections.
- Product catalogue with search and local favorites.
- Product preview/status labels (sample products are not live offers).
- AI chat interface with a secure-backend integration point.
- About page and privacy reminders.
- No payment secrets or AI API keys embedded in the Android app.

## Enable the live AI service

The Android app currently shows preview mode until you configure your HTTPS backend URL in `MainActivity.kt` (`backendUrl`).

1. Deploy the `backend` folder to a trusted server that supports Node.js 20+ and HTTPS.
2. Copy `backend/.env.example` to `.env` on the server.
3. Set `OPENAI_API_KEY` on the server environment. Never put it in Android code or GitHub source.
4. Install dependencies with `npm install` and start with `npm start`.
5. Set `backendUrl` in `MainActivity.kt` to your deployed HTTPS API origin, rebuild the APK, and test.

The backend uses Helmet, a request-size limit, input validation, a basic rate limit and a server-side API key. Before public launch, add authentication, stronger per-account quotas, monitoring, abuse controls, privacy disclosures and production security review. Do not rely on the demo rate limiter as a complete production security system.

## Before publishing or selling anything

- Replace sample product copy with accurate descriptions of real products.
- Add a real company support email and privacy-policy URL.
- Verify rights and availability for the NEXO ESTÚDIO name and logo; this project does not perform trademark clearance.
- Configure a proper account system and backend database before collecting user accounts or purchase history.
- Add a payment provider only after reviewing its age, country, business and platform requirements. Have a parent/guardian handle accounts and legal steps where required.
- For digital goods distributed inside an Android app, review Google Play billing and developer policies before implementing checkout. Do not collect card numbers directly in this app.
- Add signed release builds and protect signing credentials using GitHub Secrets; the workflow currently produces a **debug APK for testing**, not a Play Store release.
- Confirm local legal requirements and supported payment regions. The app does not block Brazil through geolocation; market exclusion is currently a business-policy setting, not an enforced region lock.

## Current limitations

This is a working app prototype, not a fully launched marketplace. The catalogue contains illustrative preview entries. Login, cloud sync, purchases, subscriptions, refunds, admin tools, notifications and real AI require deployment and further implementation. No revenue or payment processing is enabled by default.
