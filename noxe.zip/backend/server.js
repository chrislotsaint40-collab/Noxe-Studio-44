import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import "dotenv/config";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: (process.env.ALLOWED_ORIGINS || "").split(",").filter(Boolean) }));
app.use(express.json({ limit: "12kb" }));
app.use("/api/", rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "NEXO STUDIO API" }));

app.post("/api/chat", async (req, res) => {
  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  const language = req.body?.language === "pt" ? "pt" : "en";
  if (!message || message.length > 4000) {
    return res.status(400).json({ error: "Message must contain 1–4000 characters." });
  }
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ error: "AI service is not configured." });
  }

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: language === "pt"
          ? "Você é a NEXO AI, assistente útil e segura da NEXO ESTÚDIO. Responda em português. Não peça senhas, chaves ou dados de pagamento."
          : "You are NEXO AI, the helpful and safe assistant for NEXO STUDIO. Reply in English. Never ask for passwords, API keys or payment details.",
        input: message,
        max_output_tokens: 700
      })
    });
    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("AI provider returned status", upstream.status);
      return res.status(502).json({ error: "AI provider unavailable." });
    }
    const reply = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n").trim();
    if (!reply) return res.status(502).json({ error: "Empty AI response." });
    return res.json({ reply });
  } catch (err) {
    console.error("AI request failed:", err?.message || "unknown error");
    return res.status(502).json({ error: "Could not contact AI provider." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`NEXO API listening on ${port}`));
