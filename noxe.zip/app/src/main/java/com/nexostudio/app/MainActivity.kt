package com.nexostudio.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val black = Color.rgb(7, 7, 8)
    private val surface = Color.rgb(23, 23, 26)
    private val white = Color.WHITE
    private val gray = Color.rgb(175, 175, 182)
    private var language = "en"
    private var page = "home"
    private var backendUrl = "https://YOUR_BACKEND_HOST"
    private val favorites = mutableSetOf<String>()
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var chatInput: EditText
    private lateinit var chatLog: LinearLayout

    private data class Product(val id: String, val titleEn: String, val titlePt: String,
                               val descEn: String, val descPt: String, val category: String,
                               val status: String = "Coming soon")

    private val products = listOf(
        Product("nexo-ai", "NEXO AI", "NEXO AI",
            "An AI assistant for ideas, learning and productivity.",
            "Um assistente de IA para ideias, aprendizado e produtividade.", "AI"),
        Product("nexo-code", "NEXO CODE", "NEXO CODE",
            "A coding companion for developers and students.",
            "Um companheiro de programação para desenvolvedores e estudantes.", "Software"),
        Product("nexo-game", "NEXO GAME TOOLS", "NEXO GAME TOOLS",
            "Fair-play tools and utilities for game creators.",
            "Ferramentas justas e utilitários para criadores de jogos.", "Gaming"),
        Product("nexo-cloud", "NEXO CLOUD", "NEXO CLOUD",
            "A concept for organizing digital projects in one place.",
            "Um conceito para organizar projetos digitais em um só lugar.", "Cloud")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        showHome()
    }

    private fun t(en: String, pt: String) = if (language == "en") en else pt
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun params() = LinearLayout.LayoutParams(-1, -2)
    private fun gap(v: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(v)) }

    private fun setup() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(18), dp(14), dp(18), dp(10))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NEXO  ESTÚDIO"
            textSize = 20f
            letterSpacing = .08f
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        val lang = TextView(this).apply {
            text = if (language == "en") "EN  |  PT" else "PT  |  EN"
            textSize = 12f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(surface, 20)
            setOnClickListener {
                language = if (language == "en") "pt" else "en"
                render()
            }
        }
        header.addView(lang)
        root.addView(header)
        root.addView(View(this).apply { setBackgroundColor(Color.rgb(48,48,52)) },
            LinearLayout.LayoutParams(-1, dp(1)))
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, dp(20))
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        nav.addView(navItem(t("HOME","INÍCIO")) { showHome() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navItem(t("STORE","LOJA")) { showStore() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navItem("NEXO AI") { showAI() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(navItem(t("PROFILE","PERFIL")) { showProfile() }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(nav)
        setContentView(root)
    }

    private fun render() {
        when (page) {
            "store" -> showStore()
            "ai" -> showAI()
            "profile" -> showProfile()
            else -> showHome()
        }
    }

    private fun showHome() {
        page = "home"; setup()
        val logo = ImageView(this)
        val id = resources.getIdentifier("nexo_logo", "drawable", packageName)
        if (id != 0) {
            logo.setImageResource(id)
            logo.adjustViewBounds = true
            logo.scaleType = ImageView.ScaleType.FIT_CENTER
            body.addView(logo, LinearLayout.LayoutParams(-1, dp(155)))
        }
        label(t("DIGITAL PRODUCTS • AI • SOFTWARE", "PRODUTOS DIGITAIS • IA • SOFTWARE"), 11f, gray, true)
        heading(t("Ideas become technology.", "Ideias viram tecnologia."), 28f)
        paragraph(t(
            "Discover digital products, useful tools and AI experiences created by NEXO ESTÚDIO.",
            "Descubra produtos digitais, ferramentas úteis e experiências de IA criadas pela NEXO ESTÚDIO."
        ))
        button(t("EXPLORE THE STORE", "EXPLORAR A LOJA")) { showStore() }
        gap(16).also { body.addView(it) }
        heading(t("Featured projects", "Projetos em destaque"), 20f)
        products.take(3).forEach { productCard(it) }
        paragraph(t("New products will appear here as they become available.",
            "Novos produtos aparecerão aqui quando estiverem disponíveis."))
    }

    private fun showStore() {
        page = "store"; setup()
        label(t("NEXO MARKETPLACE", "LOJA NEXO"), 11f, gray, true)
        heading(t("Digital products", "Produtos digitais"), 27f)
        paragraph(t("Explore software and tools from our studio. Items marked “Coming soon” are previews, not products currently for sale.",
            "Explore softwares e ferramentas do nosso estúdio. Itens marcados como “Em breve” são prévias, não produtos à venda."))
        val search = EditText(this).apply {
            hint = t("Search products", "Buscar produtos")
            setHintTextColor(gray); setTextColor(white); textSize = 15f
            setSingleLine(true); setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(surface, 12)
        }
        body.addView(search, params())
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(list, params())
        fun populate(q: String) {
            list.removeAllViews()
            products.filter { p ->
                q.isBlank() || (if (language == "en") p.titleEn + p.descEn else p.titlePt + p.descPt)
                    .contains(q, ignoreCase = true)
            }.forEach { p -> list.addView(makeProductCard(p), params().apply { bottomMargin = dp(10) }) }
        }
        populate("")
        search.addTextChangedListener(SimpleWatcher { populate(it) })
    }

    private fun productCard(p: Product) {
        body.addView(makeProductCard(p), params().apply { bottomMargin = dp(10) })
    }

    private fun makeProductCard(p: Product): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            background = rounded(surface, 14)
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = if (language == "en") p.titleEn else p.titlePt
            textSize = 18f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val fav = TextView(this).apply {
            text = if (favorites.contains(p.id)) "♥" else "♡"
            textSize = 23f; setTextColor(white)
            setOnClickListener {
                if (!favorites.add(p.id)) favorites.remove(p.id)
                text = if (favorites.contains(p.id)) "♥" else "♡"
            }
        }
        top.addView(fav)
        card.addView(top)
        val desc = TextView(this).apply {
            text = if (language == "en") p.descEn else p.descPt
            textSize = 14f; setTextColor(gray); setPadding(0, dp(8), 0, dp(10))
        }
        card.addView(desc)
        val status = TextView(this).apply {
            text = t("COMING SOON • PREVIEW", "EM BREVE • PRÉVIA")
            textSize = 10f; letterSpacing = .1f; setTextColor(Color.LTGRAY)
        }
        card.addView(status)
        return card
    }

    private fun showAI() {
        page = "ai"; setup()
        label("NEXO AI", 12f, gray, true)
        heading(t("Your creative assistant", "Seu assistente criativo"), 26f)
        paragraph(t("Ask questions, brainstorm ideas or get help with code. Connect the secure backend described in the project README to enable live AI responses.",
            "Faça perguntas, desenvolva ideias ou peça ajuda com programação. Conecte o backend seguro descrito no README para ativar respostas reais da IA."))
        chatLog = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = rounded(surface, 12)
        }
        body.addView(chatLog, params())
        addChatBubble(t("Hello! I am the NEXO AI interface preview. The live AI service is not connected yet.",
            "Olá! Sou a prévia da interface da NEXO AI. O serviço real de IA ainda não está conectado."), false)
        body.addView(gap(10))
        chatInput = EditText(this).apply {
            hint = t("Write a message…", "Escreva uma mensagem…")
            setHintTextColor(gray); setTextColor(white); textSize = 15f
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(surface, 12)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_SEND) { sendAI(); true } else false
            }
        }
        body.addView(chatInput, params())
        body.addView(gap(8))
        button(t("SEND MESSAGE", "ENVIAR MENSAGEM")) { sendAI() }
        label(t("Privacy: do not send passwords, payment details or sensitive personal data.",
            "Privacidade: não envie senhas, dados de pagamento ou informações pessoais sensíveis."), 11f, gray, false)
    }

    private fun sendAI() {
        val message = chatInput.text.toString().trim()
        if (message.isEmpty()) return
        addChatBubble(message, true)
        chatInput.setText("")
        if (backendUrl.contains("YOUR_BACKEND_HOST")) {
            addChatBubble(t("AI is in preview mode. Configure your own HTTPS backend URL to enable responses.",
                "A IA está em modo de prévia. Configure o endereço HTTPS do seu backend para ativar as respostas."), false)
            return
        }
        addChatBubble(t("Connecting…", "Conectando…"), false)
        thread {
            val answer = requestAI(message)
            runOnUiThread {
                if (answer == null) addChatBubble(t("Could not reach the AI service. Please try again later.",
                    "Não foi possível acessar a IA. Tente novamente mais tarde."), false)
                else addChatBubble(answer, false)
            }
        }
    }

    private fun requestAI(message: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(backendUrl.trimEnd('/') + "/api/chat").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val payload = JSONObject().put("message", message).put("language", language).toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) return null
            val response = conn.inputStream.bufferedReader().use { it.readText() }
            JSONObject(response).optString("reply").takeIf { it.isNotBlank() }
        } catch (_: Exception) { null } finally { conn?.disconnect() }
    }

    private fun addChatBubble(message: String, user: Boolean) {
        val bubble = TextView(this).apply {
            text = message; textSize = 14f
            setTextColor(if (user) black else white)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(if (user) Color.WHITE else Color.rgb(43,43,48), 12)
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (user) Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
            addView(bubble, LinearLayout.LayoutParams(-2, -2).apply { maxWidth = dp(280) })
        }
        chatLog.addView(wrap)
    }

    private fun showProfile() {
        page = "profile"; setup()
        val avatar = ImageView(this)
        val logoId = resources.getIdentifier("nexo_logo", "drawable", packageName)
        if (logoId != 0) {
            avatar.setImageResource(logoId)
            avatar.scaleType = ImageView.ScaleType.CENTER_CROP
            avatar.background = rounded(surface, 18)
            avatar.clipToOutline = true
            body.addView(avatar, LinearLayout.LayoutParams(dp(112), dp(112)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(14)
            })
        }
        label(t("YOUR NEXO ACCOUNT", "SUA CONTA NEXO"), 11f, gray, true)
        heading(t("Profile", "Perfil"), 27f)
        paragraph(t("Your account area will show your details, favorites, purchases and app settings.",
            "A área da sua conta mostrará seus dados, favoritos, compras e configurações do aplicativo."))
        cardInfo(t("Favorites", "Favoritos"), "${favorites.size} " + t("saved products", "produtos salvos"))
        cardInfo(t("Purchases", "Compras"), t("Purchase history will appear after secure checkout is implemented.",
            "O histórico aparecerá depois que o checkout seguro for implementado."))
        cardInfo(t("Account security", "Segurança da conta"), t("Sign-in and account recovery are not connected in this preview.",
            "Login e recuperação de conta ainda não estão conectados nesta prévia."))
        button(t("ABOUT NEXO STUDIO", "SOBRE A NEXO ESTÚDIO")) { showAbout() }
    }

    private fun showAbout() {
        page = "about"; setup()
        heading(t("About NEXO ESTÚDIO", "Sobre a NEXO ESTÚDIO"), 26f)
        paragraph(t("An independent digital studio building software, AI experiences and tools for creators around the world.",
            "Um estúdio digital independente que desenvolve softwares, experiências de IA e ferramentas para criadores ao redor do mundo."))
        cardInfo(t("Our focus", "Nosso foco"), t("Useful products, clear design and responsible technology.",
            "Produtos úteis, design claro e tecnologia responsável."))
        cardInfo(t("Availability", "Disponibilidade"), t("International concept excluding Brazil for the planned launch. Actual availability depends on local laws and supported payment providers.",
            "Conceito internacional, excluindo o Brasil no lançamento planejado. A disponibilidade real depende das leis locais e dos provedores de pagamento."))
        cardInfo(t("Contact", "Contato"), t("Add a verified business email before public release.",
            "Adicione um e-mail comercial verificado antes do lançamento público."))
    }

    private fun cardInfo(title: String, desc: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(surface, 12)
        }
        val h = TextView(this).apply { text = title; textSize = 16f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD }
        val d = TextView(this).apply { text = desc; textSize = 13f; setTextColor(gray); setPadding(0, dp(6), 0, 0) }
        box.addView(h); box.addView(d)
        body.addView(box, params().apply { bottomMargin = dp(10) })
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean) {
        val v = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(3), 0, dp(8))
        }
        body.addView(v, params())
    }

    private fun heading(value: String, size: Float) {
        val v = TextView(this).apply {
            text = value; textSize = size; setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(5), 0, dp(8))
        }
        body.addView(v, params())
    }

    private fun paragraph(value: String) {
        val v = TextView(this).apply {
            text = value; textSize = 14f; setTextColor(gray)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(0, 0, 0, dp(14))
        }
        body.addView(v, params())
    }

    private fun button(value: String, click: () -> Unit) {
        val b = TextView(this).apply {
            text = value; textSize = 12f; gravity = Gravity.CENTER
            setTextColor(black); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(16), dp(15), dp(16), dp(15))
            background = rounded(white, 10)
            setOnClickListener { click() }
        }
        body.addView(b, params())
    }

    private fun navItem(value: String, click: () -> Unit) = TextView(this).apply {
        text = value; textSize = 10f; gravity = Gravity.CENTER
        setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        setOnClickListener { click() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
}

private class SimpleWatcher(val changed: (String) -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { changed(s?.toString() ?: "") }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
